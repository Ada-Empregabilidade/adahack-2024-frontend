// Use npm run server
export const BASE_URL = "http://localhost:3000/empresas";

export const USERS_BASE_URL = "http://localhost:3000/users";